// path 경로가 잘못됐을시 보여줄 에러 출력 화면 설정하는 중
function NotFound() {
  return (
    <>
      <h2 style={{color: 'red'}}>낫 파운드</h2>
    </>
  )
}

export default NotFound;